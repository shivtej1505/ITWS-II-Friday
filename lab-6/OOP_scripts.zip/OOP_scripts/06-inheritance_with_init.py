#!/usr/bin/python 
# Demo of creating subclass-superclass relation (Inheritance) of a SHAPE class 


class Shape:					# parent class 
	def __init__(self):
		self.color = 'black'		

class Rectangle(Shape):				# child class 1 
	def __init__(self, w, l):		# its own constructor 
		Shape.__init__(self)		# parent's constructor 	
						# What if you comment the above line?
		self.width = w
		self.length = l
		
	def area(self):
		return self.width * self.length
	

class Circle(Shape):				# child class 2
	def __init__(self, r):
		Shape.__init__( self )		# parent's constructor 	
		self.rad = r
	
	def area(self):
		return 3.14 * self.rad ** 2


r = Rectangle(10, 5)					# class instance 
c = Circle(8) 						# class instance 

print("Width of the rectangle: ", r.width)
print("Length of the rectangle: ", r.length)
print("Area of the rectangle: ", r.area())
print("Color of the rectangle: ", r.color)              # inheritted 

print("Radius of the circle: ", c.rad)
print("Area of the circle: ", c.area()) 
print("Color of the circle: ", c.color) 		# inheritted 	

