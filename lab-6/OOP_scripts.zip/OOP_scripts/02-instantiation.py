#!/usr/bin/python 

# demo of class instantiation using the __init__ special method 

# we do not explicitly call the __init__ method but pass the arguments in the parentheses following the class name when creating a new instance of the class.


class person: 
	def __init__(self, who):      # default constructor 
		self.name = who 

	def display(self):           
		print('Hello', self.name)

I1 = person('Alice')                	# first instance 

print(I1.name)				# access the class members
I1.display()				

I2 = person('Bob')			# another instance
I2.display() 

person('Charlie').display() 		# ??
