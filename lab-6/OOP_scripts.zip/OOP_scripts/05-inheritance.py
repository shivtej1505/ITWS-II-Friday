#!/usr/bin/python 

# simple demo of creating subclasses in Python 


class parent: 	
	def parentmethod(self):
		print('Inside parent method')
	
class child(parent): 
	def childmethod(self):
		print('Inside child method')


p = parent()				# instance of 'parent' class

c = child()             	  	# instance of 'child' class

p.parentmethod() 

c.childmethod()

#p.childmethod() 			# ??? 

#c.parentmethod()       		# ??? 

# Uncomment these too
#print "Is child a subclass of parent?", issubclass(child,parent)
#print "Is c an instance of child:", isinstance(c,child)
#print "Is c an instance of parent:", isinstance(c,parent)
#print "Is p an instance of child:", isinstance(p,child)
#print "Is p an instance of parent:", isinstance(p,parent)

#print "class of c:", c.__class__
#print "class of p:", p.__class__

