#!/usr/bin/python 

class MyMath: 
	""" demo of class methods and instances """

	def add(self, x, y): 
		return x+y 

	def sub(self, x, y):
		return x-y 

	def mul(self, x, y):
		return x*y 

	def div(self, x, y):
		return x/y 

	def compute(self):
		print(self.add(2, 4))	# calling the add() method of same class, thus 'self' needed
		print(self.sub(2, 4))
		print(self.mul(2, 4))
		print(self.div(2, 4))
			  
I = MyMath()     			# creating a class instance = instantiation

I.compute()			# same as MyMath.compute(I) 
				# i.e. the object itself is passed as the first argument of the function.			

print('--------------')

print(I.add(2,4)) 		# = MyMath.add(I,2,4)
print(I.sub(2,4))
print(I.mul(2,4))
print(I.div(2,4))

print('--------------')
