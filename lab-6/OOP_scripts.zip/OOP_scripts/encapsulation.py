#!/usr/bin/python 

# class definition to be used by '08b-data_hiding.py' 
# classes can be imported just like modules 

class privacy :
	def __init__(self, a, b):
		self.public = a			# a is public 
		self.__private = b		# b is a private member 

#x = privacy(1, 2)
#print(x.public)
#print(x.private)
