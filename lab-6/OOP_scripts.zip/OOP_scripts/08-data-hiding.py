#!/usr/bin/python

# Uses the class definition from the file, "encapsulation.py"

from encapsulation import privacy  		# classes too can be imported

x = privacy(1, 2)

print("public: ", x.public)

print("private: ", x.__private)		# ???


