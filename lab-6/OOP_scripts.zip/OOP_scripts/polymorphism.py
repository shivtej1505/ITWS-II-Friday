#!/usr/bin/python

# Demo of polymorphism ("many forms") in Python 
 
class Animal:
	def __init__(self, name):                    # constructor
		self.name = name

	def talk(self):
		#raise NotImplementedError("Subclass must implement abstract method") # subclasses need to implement their own talk() methods	
		pass                            # that is different/polymorphic for each animal type
	

class Cat(Animal):
	def talk(self):
		return 'Meow!'
	
class Dog(Animal):
	def talk(self):
		return 'Woof! Woof!'

animals = [Cat('Missy'), Dog('Lassie')]

for i in animals:
	print(i.name + ' --> ' + i.talk())
