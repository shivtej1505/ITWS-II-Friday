#!/usr/bin/python 

# An example of method overriding through inheritance 

class parent: 

	def func(self):
		print("This is parent's func() ")
		self.say()
		
	def say(self):
		print("Hello from parent")


class child(parent): 

	def func(self): 			# method overridden 
		print("This is child's func()")
		self.say()			# What about p.say() ??
		
	def say(self): 
		print("Hello from child")

p = parent() 

c = child() 

p.func() 
print("-------------")
c.func() 

