#!/usr/bin/python 

# yet another demo of class instantiation 

class AddressBook:
	""" This class creates/updates an address book entry"""

	def __init__(self, x, y):		# two-argument constructor 
		self.name = x
		self.phone = y
		print('Created instance for:', self.name)

	def updatePhone(self, newph):
		self.phone = newph
		print('Updated phone # for:', self.name)


I1 = AddressBook('John Kumar', '+91-1234-5678-90')		# object 1

I2 = AddressBook('Mary Joseph', '+91-40-0123-4567') 		# object 2

print("First instance -->", I1.name, I1.phone)

print("Second instance -->", I2.name, I2.phone) 

I1.updatePhone('+91-9876-5432-10') 

print("Updated info -->", I1.name, I1.phone)

